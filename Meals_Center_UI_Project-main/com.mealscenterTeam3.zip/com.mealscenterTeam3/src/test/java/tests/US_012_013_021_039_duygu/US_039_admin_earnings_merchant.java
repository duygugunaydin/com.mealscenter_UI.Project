package tests.US_012_013_021_039_duygu;

import org.testng.annotations.Test;

public class US_039_admin_earnings_merchant {
    @Test
    public void test1(){
        /*
         *Tarayıcı açılır.
         *Url e gidilir.
         *Administrator sayfasına login olunur.
         *Dahboard panelindeki 'Earnings' menusune tıklanır.
         *'Earnings' menusundeki 'Merchant Earnings' menusüne tıklanır.
         *Yüklenen sayfada Merchantların kazanç listesi olduğu doğrulanır.
         *Tarayici kapatılır.
         */
    }
    @Test
    public void test2(){
        /*
         *Tarayıcı açılır.
         *Url e gidilir.
         *Administrator sayfasına login olunur.
         *Dahboard panelindeki 'Earnings' menusune tıklanır.
         *'Earnings' menusundeki 'Merchant Earnings' menusüne tıklanır.
         *Yüklenen sayfada Merchantların total kazanç bilgisi olduğu doğrulanır.
         *Tarayici kapatılır.
         */
    }
    @Test
    public void test3(){
        /*
         *Tarayıcı açılır.
         *Url e gidilir.
         *Administrator sayfasına login olunur.
         *Dahboard panelindeki 'Earnings' menusune tıklanır.
         *'Earnings' menusundeki 'Merchant Earnings' menusüne tıklanır.
         *Yüklenen sayfadaki listenin Merchant ve Balance bilgisine göre listelendiği doğrulanır.
         *Tarayici kapatılır.
         */
    }
    @Test
    public void test4(){
        /*
         *Tarayıcı açılır.
         *Url e gidilir.
         *Administrator sayfasına login olunur.
         *Dahboard panelindeki 'Earnings' menusune tıklanır.
         *'Earnings' menusundeki 'Merchant Earnings' menusüne tıklanır.
         *Yüklenen sayfadaki listede Merchant kazanclarının detay bilgisi olduğu doğrulanır.
         *Tarayici kapatılır.
         */
    }
    @Test
    public void test5(){
        /*
         *Tarayıcı açılır.
         *Url e gidilir.
         *Administrator sayfasına login olunur.
         *Dahboard panelindeki 'Earnings' menusune tıklanır.
         *'Earnings' menusundeki 'Merchant Earnings' menusüne tıklanır.
         *Yüklenen sayfada listedeki merchantları aranabileceği searchbox olduğu doğrulanır.
         *Tarayici kapatılır.
         */
    }
}
