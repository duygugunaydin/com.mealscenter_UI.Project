package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

import java.util.List;

public class Merchant_Dashboard {

    public Merchant_Dashboard(){
        PageFactory.initElements(Driver.getDriver(),this);
    }

    //Merchant Login/usernameBox
    @FindBy(xpath = "(//input[@class='form-control form-control-text'])[1]")
    public WebElement usernameBox;

    //Merchant Login/passwordBox
    @FindBy (xpath = "(//input[@class='form-control form-control-text'])[2]")
    public WebElement passwordBox;

    //Merchant Login/signInButton
    @FindBy (xpath = "//input[@class='btn btn-green btn-full']")
    public WebElement signInButton;

    //merchant>dashboard/orders link
    @FindBy (xpath = "//li[@class='merchant_orders']")
    public WebElement ordersLink;

    //merchant>dashboard/scheduled Link
    @FindBy (xpath = "//a[text()='Scheduled']")
    public WebElement scheduledLink;

    //merchant>backoffice/orders>scheduled/scheduledBaslikText
    @FindBy (xpath = "//div[@class='flex-col d-none d-lg-block']")
    public WebElement scheduledBaslikText;

    //merchant>backoffice/orders>scheduled/completedTodayCount
    @FindBy (xpath = "//div[@class='ronded-green']")
    public WebElement completedTodayCount;

    //merchant>backoffice/orders>scheduled/acceptedButton
    @FindBy (xpath = "//button[@class='btn-green btn normal mr-2 font13 mb-3 mb-xl-0']")
    public WebElement acceptedButton;

    //merchant>backoffice/orders>scheduled/rejectButton
    @FindBy (xpath = "//span[text()='Reject']")
    public WebElement rejectButton;

    //backoffice/orders/scheduled>assignDriverButton
    @FindBy (xpath = "//button[@class='btn btn-primary']")
    public WebElement assignDriverButton;


    // /backoffice/merchant/dashboard >> Dasboard menusunun tamami
    @FindBy(xpath = "//div[@id='vue-siderbar-menu']")
    public WebElement dasboardMenusununTamami;

    // /backoffice/merchant/dashboard >> Dasboard menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[1]")
    public WebElement dashboardMenuButonu;

    // /backoffice/merchant/dashboard >> Merchant menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[2]")
    public WebElement merchantMenuButonu;

    // /backoffice/merchant/dashboard >> Orders menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[3]")
    public WebElement ordersMenuButonu;

    // /backoffice/merchant/dashboard >> Attributes menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[6]")
    public WebElement attributesMenuButonu;

    // /backoffice/merchant/dashboard >> Food menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[7]")
    public WebElement foodMenuButonu;

    // /backoffice/merchant/dashboard >> Order menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[8]")
    public WebElement orderTypeMenuButonu;

    // /backoffice/merchant/dashboard >> Payment Gateway menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[9]")
    public WebElement paymentGatewayMenuButonu;

    // /backoffice/merchant/dashboard >> Promo menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[10]")
    public WebElement promoMenuButonu;

    // /backoffice/merchant/dashboard >> Images menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[11]")
    public WebElement imagesMenuButonu;

    // /backoffice/merchant/dashboard >> Account menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[12]")
    public WebElement accountMenuButonu;

    // /backoffice/merchant/dashboard >> Buyers menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[14]")
    public WebElement buyersMenuButonu;

    // /backoffice/merchant/dashboard >> Users menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[15]")
    public WebElement usersMenuButonu;

    // /backoffice/merchant/dashboard >> Reports menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[16]")
    public WebElement reportsMenuButonu;

    // /backoffice/merchant/dashboard >> Inventory Management menusu butonu
    @FindBy(xpath = "(//ul[@class='sidebar-nav']/li)[18]")
    public WebElement inventoryManagementMenuButonu;

    // merchant login > image
    @FindBy(xpath = "//div[@class='col-md-6 m-0 p-0 left-container']")
    public WebElement loginImage;

    // merchant login > merchant login yazısı
    @FindBy(xpath = "//h6[@class='mb-4']")
    public WebElement textMerchantLogin;

    // merchant login > meals center amblemi
    @FindBy(xpath = "//img[@class='img-60 rounded-circle']")
    public WebElement amblem;

    // merchant login > remember me kutucuğu
    @FindBy(xpath = "//div[@class='custom-checkbox ml-3']")
    public WebElement rememberMeKutucuk;

    // merchant login > App store download linki
    @FindBy(xpath = "(//div[@class='p-2'])[1]")
    public WebElement appStoreLink;

    // merchant login > Play store download linki
    @FindBy(xpath = "(//div[@class='p-2'])[1]")
    public WebElement playStoreLink;

    // merchant login > This field is required yazısı
    @FindBy(xpath = "(//div[@class='errorMessage'])[1]")
    public WebElement requiredText;

    // merchant login > Incorrect username or password yazısı
    @FindBy(xpath = "//div[@class='errorMessage']")
    public WebElement incorrectText;


    //merchant > Dasshboard / All Orders link
    @FindBy (xpath = "//li[@class='position-relative orders_history']")
    public WebElement allOrdersLink;


    //merchant > Dasshboard / All Orders link
    @FindBy (xpath = "//a[text()='All Orders']")
    public WebElement allOrdersLinkText;

    //merchant > Dasshboard / orderHistory
    @FindBy (xpath = "//a[@class='navbar-brand']")
    public WebElement orderHistoryText;


    //Merchant>backoffice>orders>completed
    @FindBy(xpath = "//li[@class='position-relative orders_completed']")
    public WebElement completedLink;


    @FindBy(xpath = "//h5[@class='head m-0']")
    public WebElement completedText;

    //merchant>backoffice/orders>completed/completedtodayCount

    @FindBy(xpath = "(//div[@class='col'])[1]")
    public List<WebElement> completedtodayOrdersList;

    //merchant>backoffice/orders>completed/ordertypeddm
    @FindBy(xpath = "(//select[@class='selectpicker'])[1]")
    public WebElement orderTypeDdm;

    //merchant>backoffice/orders>completed/paymentstatusddm
    @FindBy(xpath = "//select[@title='Payment status']")
    public WebElement paymentStatusDdm;

    //merchant>backoffice/orders>completed/sortddm
    @FindBy(xpath = "//select[@title='Sort']")
    public WebElement sortDdm;
    //merchant>backoffice/orders>completed/acceptingOrdersButton
    @FindBy(xpath = "//button[@class='btn btn-green']")
    public WebElement acceptingOrdersButton;

    //merchant>backoffice/orders>completed/cancelButton
    @FindBy(xpath = "(//span[text()='Cancel'])[1]")
    public WebElement  cancelButton;

    //merchant>dashboard>ordertype
    @FindBy(xpath ="//li[@class='services_settings']")
    public WebElement orderTypeLink;

    //merchant>dashboard>ordertype>delivery
    @FindBy(xpath ="//a[@href='/backoffice/services/delivery_settings']")
    public WebElement deliveryLink;

    //merchant>dashboard>ordertype>delivery>settingtext
    @FindBy(xpath ="(//li[@class='active'])[1]")
    public WebElement settingText;

    //merchant>dashboard>ordertype>delivery>checkbox1
    @FindBy(xpath = "//label[@for='merchant_opt_contact_delivery']")
    public WebElement checkbox1;
    //merchant>dashboard>ordertype>delivery>checkbox2

    @FindBy(xpath = "//label[@for='free_delivery_on_first_order']")
    public WebElement checkbox2;

    //merchant>dashboard>ordertype>delivery>fixedchargeddm
    @FindBy(xpath = "//select[@id='AR_option_merchant_delivery_charges_type']")
    public WebElement fixedchargeDdm;

    //merchant>dashboard>ordertype>delivery>servicefeebox
    @FindBy(xpath ="//input[@type='text']")
    public WebElement serviceFeeBox;

    //merchant>dashboard>ordertype>delivery
    @FindBy(xpath = "//div[@class='errorMessage']")
    public WebElement errorMessage;

    //merchant>dashboard>ordertype>delivery>savebutton
    @FindBy(xpath = "//input[@type='submit']")
    public WebElement saveButon;

    //merchant>dashboard>ordertype>delivery>settingsSavedText
    @FindBy(xpath = "//div[@class='alert alert-success']")
    public WebElement settingsSavedText;

    //merchant>dashboard>ordertype>delivery>fixedchargetext
    @FindBy(xpath ="//a[@href='/backoffice/services/fixed_charge'][1]")
    public WebElement fixedChargeText;

    //merchant>dashboard>ordertype>delivery>pricebox
    @FindBy(xpath = "(//input[@type='text'])[1]")
    public WebElement priceBox;

    //merchant>dashboard>ordertype>delivery>fixedchargesavebutton
    @FindBy(xpath = "//input[@type='submit']")
    public WebElement fixedChargeSaveButon;

    //merchant>dashboard>ordertype>delivery>alert
    @FindBy(xpath = "//div[@class='alert alert-success']")
    public WebElement succesfullyupdatedalert;

    //merchant/dashboard>AllOrders un yanında yazan sayı
    @FindBy(xpath = "//div[@class='badge-pill pull-right badge-notification bg-history']")
    public WebElement allOrdersCount;

    //backoffice/orders/history > header daki Orders sayısı
    @FindBy(xpath = "(//h5[@class='m-0'])[1]")
    public WebElement ordersCount;

    //backoffice/orders/history > sayfanın en altindaki entries sayisi
    @FindBy(xpath = "//div[@class='col-sm-12 col-md-5']")
    public WebElement entriesCount;

    //backoffice/orders/history > Start date end date
    @FindBy(xpath = "//div[@class='input-group fixed-width-field mr-2']")
    public WebElement startDateEndDate;


    //backoffice/orders/history > Start date end date secim Yesterday
    @FindBy(xpath = "//li[@data-range-key='Yesterday']")
    public WebElement tarihSecimiYesterday;

    //backoffice/orders/history > header cancel sayisi
    @FindBy(xpath = "(//h5[@class='m-0'])[2]")
    public WebElement cancelCount;

    //backoffice/orders/history > header Total refund miktari
    @FindBy(xpath = "(//h5[@class='m-0'])[3]")
    public WebElement totalRefundMoney;

    //backoffice/orders/history > header Total Orders miktari
    @FindBy(xpath = "(//h5[@class='m-0'])[4]")
    public WebElement totalOrdersMoney;


    //backoffice/orders/history > header Filters buttonu
    @FindBy(xpath = "//button[@class='btn btn-yellow normal']")
    public WebElement filtersButton;


    //backoffice/orders/history > header Filters buttonu tiklayinca çikan bolumun ikinci secenegi
    @FindBy(xpath = "(//span[@class='select2-selection select2-selection--single'])[2]")
    public WebElement byStatusBox;


    //backoffice/orders/history > header Filters buttonu tıklayınca cıkan bolumdeki applyFiltersButton
    @FindBy(xpath = "//button[@class='btn btn-green w-100']")
    public WebElement applyFiltersButton;

    //backoffice/orders/history > musteri listesinin basligi
    @FindBy(xpath = "(//th[@class='sorting_disabled'])[2]")
    public WebElement customerBaslik;

    //backoffice/orders/history > musteri listesinin basligi
    @FindBy(xpath = "(//th[@class='sorting_disabled'])[3]")
    public WebElement orderInformationBaslik;

    //backoffice/orders/history > musteri listesinin basligi
    @FindBy(xpath = "(//th[@class='sorting_disabled'])[4]")
    public WebElement actionsBaslik;

    //backoffice/orders/history > musteri listesinin basligi
    @FindBy(xpath = "//th[@class='sorting sorting_desc']")
    public WebElement orderIDBaslik;


    //backoffice/orders/history > musteri listesindeki ilk musteri
    @FindBy(xpath = "(//tr[@class='odd'])[1]")
    public WebElement musteriBilgi;


    //backoffice/orders/history > musteri listesindeki ilk gosterButtonu
    @FindBy(xpath = "(//a[@class='btn btn-light tool_tips'])[1]")
    public WebElement gosterButtonu;


    //backoffice/orders/history > musteri listesindeki ilk musteri downloadButtonu
    @FindBy(xpath = "(//a[@class='btn btn-light tool_tips'])[2]")
    public WebElement downloadButtonu;


    //=================== Size Page=======================

    //merchant/dashboard > attributesLinki
    @FindBy(xpath = "//li[@class='attributes']")
    public WebElement attributesLinki;


    //merchant/dashboard > attributesLinki> sizeLinki
    @FindBy(xpath = "//li[@class='position-relative attrmerchant_size_list']")
    public WebElement sizeLinki;



    //merchant/dashboard > attributesLinki> sizeLinki sayfa aktifken
    @FindBy(xpath = "//li[@class='position-relative attrmerchant_size_list active']")
    public WebElement sizeLinkiActive;


    //merchant/dashboard > attributesLinki> sizeLink > sizeSayfasiBasligi
    @FindBy(xpath = "//a[@class='navbar-brand']")
    public WebElement sizeSayfasiBasligi;


    //merchant/dashboard > attributesLinki>  size list Sayfasi
    @FindBy(xpath = "(//th[@class='sorting'])[1]")
    public WebElement noBasligi;


    //merchant/dashboard > attributesLinki>  size list Sayfasi
    @FindBy(xpath = "(//th[@class='sorting'])[2]")
    public WebElement nameBasligi;


    //merchant/dashboard > attributesLinki>  size list Sayfasi
    @FindBy(xpath = "(//th[@class='sorting'])[3]")
    public WebElement actionsBasligi;


    //merchant/dashboard > attributesLinki>  size list Sayfasi
    @FindBy(xpath = "//input[@class='form-control rounded search w-25']")
    public WebElement searchSizeBox;


    //merchant/dashboard > attributesLinki>  size list Sayfasi
    @FindBy(xpath = "(//input[@type='search']")
    public WebElement searchSizeBox2;


    //merchant/dashboard > attributesLinki>  size list Sayfasi
    @FindBy(xpath = "//a[@type='button']")
    public WebElement addNewButton;


    //================ Add Size ==============================

    //merchant/dashboard > attributesLinki>  size list Add Size
    @FindBy(xpath = "(//input[@class='form-control form-control-text'])[1]")
    public WebElement sizeNameBox;


    //merchant/dashboard > attributesLinki>  size list Add Size
    @FindBy(xpath = "//input[@id='AR_size_size_name']")
    public WebElement sizeNameBox2;


    //merchant/dashboard > attributesLinki>  size list Add Size
    @FindBy(xpath = "//input[@class='btn btn-green btn-full mt-3']")
    public WebElement saveButton;


    //merchant/dashboard > attributesLinki>  size list Add Size
    @FindBy(xpath = "(//h6)[2]")
    public WebElement listIlkName;

    //merchant/dashboard > attributesLinki>  size list Add Size
    @FindBy(xpath = "(//a[@class='btn btn-light datatables_delete tool_tips'])[1]")
    public WebElement deleteButtonSizeAll;


    //merchant/dashboard > attributesLinki>  size list Add Size
    @FindBy(xpath = "//a[@class='btn btn-green item_delete']")
    public WebElement deleteConfirmationButton;


    //merchant/dashboard > attributesLinki>  size list Add Size
    @FindBy(xpath = "(//a[@class='btn btn-light tool_tips'])[1]")
    public WebElement updateButton;


    //merchant/dashboard > attributesLinki> Update Size/ Succesfully UpdatedYazisi
    @FindBy(xpath = "//div[@class='alert alert-success']")
    public WebElement succesfullyUpdatedYazisi;


    //merchant/dashboard > attributesLinki>ingredientsLinki
    @FindBy(xpath = "//li[@class='position-relative attrmerchant_ingredients_list']")
    public WebElement ingredientsLinki;


    //merchant/dashboard > attributesLinki>ingredientsLinki
    @FindBy(xpath = "//li[@class='position-relative attrmerchant_ingredients_list active']")
    public WebElement ingredientsLinkiActive;


    //merchant/dashboard > attributesLinki>cookingReferenceLinki
    @FindBy(xpath = "//li[@class='position-relative attrmerchant_cookingref_list']")
    public WebElement cookingReferenceLinki;


    //merchant/dashboard > attributesLinki>cookingReferenceLinki
    @FindBy(xpath = "//li[@class='position-relative attrmerchant_cookingref_list active']")
    public WebElement cookingReferenceLinkiActive;









}
